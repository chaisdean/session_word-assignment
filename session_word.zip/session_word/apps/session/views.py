from __future__ import unicode_literals
from django.shortcuts import render, HttpResponse, redirect
from datetime import datetime

# Create your views here.

def session(request):
    return render(request, 'session/index.html')

def new_word(request):
    new_word = {}
    for key, value in request.POST.iteritems():
        if key != 'csrfmiddlewaretoken' and key != 'bigfont':
            new_word[key] = value
        if key == "bigfont":
            new_word['big'] = 'big'
        else:
            new_word['big'] = ""
    new_word['created_at'] = datetime.now().strftime('%H:%M %p, %B %d, %Y')
    try:
        request.session['words']
    except KeyError:
        request.session['words'] = []

    temp_words = request.session['words']
    temp_words.append(new_word)
    request.session['words'] = temp_words
    for key, val in request.session.__dict__.iteritems():
        print key, val
    print "created at", new_word
    return redirect('/')

def clear(request):
    for key in request.session.keys():
        del request.session[key]
    return redirect('/')
