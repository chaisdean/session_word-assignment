# from django.conf.urls import url
# from . import views
#
# urlpatterns = [
#     url(r'^$', views.form),
#     url(r'^form/process$', views.process),
#     url(r'^result$', views.result)
# ]



from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^$', views.session),
    url(r'^new_word$', views.new_word),
    url(r'^clear$', views.clear),
]
